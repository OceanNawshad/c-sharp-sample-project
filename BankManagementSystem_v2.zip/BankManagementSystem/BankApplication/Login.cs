﻿using BankRepository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankApplication
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void ExitBtnClicked(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginBtnClicked(object sender, EventArgs e)
        {
            Employee user = new Employee();
            user.EmployeeId = this.idTBox.Text;
            user.Password = this.passTBox.Text;

            EmployeeRepository empRepo = new EmployeeRepository();
            if (empRepo.UserLoginVerification(user))
            {
                Home h = new Home();
                h.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid ID or Password", "Login Failed");
            }
        }
    }
}
