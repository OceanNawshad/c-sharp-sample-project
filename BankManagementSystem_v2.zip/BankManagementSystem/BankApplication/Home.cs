﻿using BankRepository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankApplication
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void loadAccountBtnClicked(object sender, EventArgs e)
        {
            AccountRepository accRepo = new AccountRepository();
            List<Account> accList = accRepo.GetAllAccounts();
            this.accountGridView.DataSource = accList;
        }

        private void insertAccountBtnClicked(object sender, EventArgs e)
        {
            Account a = new Account();
            a.AccountId = this.textBox1.Text;
            a.AccountHolderName = this.textBox2.Text;
            a.Balance = Convert.ToDouble(this.textBox3.Text);

            AccountRepository accRepo = new AccountRepository();

            if (accRepo.Insert(a))
            {
                List<Account> accList = accRepo.GetAllAccounts();
                this.accountGridView.DataSource = accList;
            }
            else
            {
                MessageBox.Show("Insert Not Complete", "Error");
            }
        }

        private void updateAccountBtnClicked(object sender, EventArgs e)
        {

        }

        private void deleteAccountBtnClicked(object sender, EventArgs e)
        {

        }

        private void searchAccountBtnClicked(object sender, EventArgs e)
        {
            string text = this.searchAccountTBox.Text;
            AccountRepository accRepo = new AccountRepository();
            List<Account> accList = accRepo.SearchAccounts(text);
            this.accountGridView.DataSource = accList;
        }

        private void LogoutBtnClicked(object sender, EventArgs e)
        {
            Login lg = new Login();
            lg.Show();
            this.Hide();
        }
    }
}
