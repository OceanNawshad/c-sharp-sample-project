﻿namespace BankApplication
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.accountGridView = new System.Windows.Forms.DataGridView();
            this.employeeGridView = new System.Windows.Forms.DataGridView();
            this.loadAccountBtn = new System.Windows.Forms.Button();
            this.insertAccountBtn = new System.Windows.Forms.Button();
            this.updateAccountBtn = new System.Windows.Forms.Button();
            this.deleteAccountBtn = new System.Windows.Forms.Button();
            this.searchAccountBtn = new System.Windows.Forms.Button();
            this.searchAccountTBox = new System.Windows.Forms.TextBox();
            this.searchEmployeeTBox = new System.Windows.Forms.TextBox();
            this.searchEmployeeBtn = new System.Windows.Forms.Button();
            this.deleteEmployeeBtn = new System.Windows.Forms.Button();
            this.updateEmployeeBtn = new System.Windows.Forms.Button();
            this.insertEmployeeBtn = new System.Windows.Forms.Button();
            this.loadEmployeeBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.changePassBtn = new System.Windows.Forms.Button();
            this.logoutBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.accountGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Location = new System.Drawing.Point(83, 50);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(52, 13);
            this.welcomeLabel.TabIndex = 0;
            this.welcomeLabel.Text = "Welcome";
            // 
            // accountGridView
            // 
            this.accountGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.accountGridView.Location = new System.Drawing.Point(424, 12);
            this.accountGridView.Name = "accountGridView";
            this.accountGridView.Size = new System.Drawing.Size(525, 174);
            this.accountGridView.TabIndex = 1;
            // 
            // employeeGridView
            // 
            this.employeeGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeGridView.Location = new System.Drawing.Point(424, 240);
            this.employeeGridView.Name = "employeeGridView";
            this.employeeGridView.Size = new System.Drawing.Size(525, 174);
            this.employeeGridView.TabIndex = 2;
            // 
            // loadAccountBtn
            // 
            this.loadAccountBtn.Location = new System.Drawing.Point(424, 202);
            this.loadAccountBtn.Name = "loadAccountBtn";
            this.loadAccountBtn.Size = new System.Drawing.Size(75, 23);
            this.loadAccountBtn.TabIndex = 3;
            this.loadAccountBtn.Text = "Load";
            this.loadAccountBtn.UseVisualStyleBackColor = true;
            this.loadAccountBtn.Click += new System.EventHandler(this.loadAccountBtnClicked);
            // 
            // insertAccountBtn
            // 
            this.insertAccountBtn.Location = new System.Drawing.Point(505, 202);
            this.insertAccountBtn.Name = "insertAccountBtn";
            this.insertAccountBtn.Size = new System.Drawing.Size(75, 23);
            this.insertAccountBtn.TabIndex = 4;
            this.insertAccountBtn.Text = "Insert";
            this.insertAccountBtn.UseVisualStyleBackColor = true;
            this.insertAccountBtn.Click += new System.EventHandler(this.insertAccountBtnClicked);
            // 
            // updateAccountBtn
            // 
            this.updateAccountBtn.Location = new System.Drawing.Point(586, 202);
            this.updateAccountBtn.Name = "updateAccountBtn";
            this.updateAccountBtn.Size = new System.Drawing.Size(75, 23);
            this.updateAccountBtn.TabIndex = 5;
            this.updateAccountBtn.Text = "Update";
            this.updateAccountBtn.UseVisualStyleBackColor = true;
            this.updateAccountBtn.Click += new System.EventHandler(this.updateAccountBtnClicked);
            // 
            // deleteAccountBtn
            // 
            this.deleteAccountBtn.Location = new System.Drawing.Point(667, 202);
            this.deleteAccountBtn.Name = "deleteAccountBtn";
            this.deleteAccountBtn.Size = new System.Drawing.Size(75, 23);
            this.deleteAccountBtn.TabIndex = 6;
            this.deleteAccountBtn.Text = "Delete";
            this.deleteAccountBtn.UseVisualStyleBackColor = true;
            this.deleteAccountBtn.Click += new System.EventHandler(this.deleteAccountBtnClicked);
            // 
            // searchAccountBtn
            // 
            this.searchAccountBtn.Location = new System.Drawing.Point(874, 202);
            this.searchAccountBtn.Name = "searchAccountBtn";
            this.searchAccountBtn.Size = new System.Drawing.Size(75, 23);
            this.searchAccountBtn.TabIndex = 7;
            this.searchAccountBtn.Text = "Search";
            this.searchAccountBtn.UseVisualStyleBackColor = true;
            this.searchAccountBtn.Click += new System.EventHandler(this.searchAccountBtnClicked);
            // 
            // searchAccountTBox
            // 
            this.searchAccountTBox.Location = new System.Drawing.Point(768, 204);
            this.searchAccountTBox.Name = "searchAccountTBox";
            this.searchAccountTBox.Size = new System.Drawing.Size(100, 20);
            this.searchAccountTBox.TabIndex = 8;
            // 
            // searchEmployeeTBox
            // 
            this.searchEmployeeTBox.Location = new System.Drawing.Point(768, 430);
            this.searchEmployeeTBox.Name = "searchEmployeeTBox";
            this.searchEmployeeTBox.Size = new System.Drawing.Size(100, 20);
            this.searchEmployeeTBox.TabIndex = 14;
            // 
            // searchEmployeeBtn
            // 
            this.searchEmployeeBtn.Location = new System.Drawing.Point(874, 428);
            this.searchEmployeeBtn.Name = "searchEmployeeBtn";
            this.searchEmployeeBtn.Size = new System.Drawing.Size(75, 23);
            this.searchEmployeeBtn.TabIndex = 13;
            this.searchEmployeeBtn.Text = "Search";
            this.searchEmployeeBtn.UseVisualStyleBackColor = true;
            // 
            // deleteEmployeeBtn
            // 
            this.deleteEmployeeBtn.Location = new System.Drawing.Point(667, 428);
            this.deleteEmployeeBtn.Name = "deleteEmployeeBtn";
            this.deleteEmployeeBtn.Size = new System.Drawing.Size(75, 23);
            this.deleteEmployeeBtn.TabIndex = 12;
            this.deleteEmployeeBtn.Text = "Delete";
            this.deleteEmployeeBtn.UseVisualStyleBackColor = true;
            // 
            // updateEmployeeBtn
            // 
            this.updateEmployeeBtn.Location = new System.Drawing.Point(586, 428);
            this.updateEmployeeBtn.Name = "updateEmployeeBtn";
            this.updateEmployeeBtn.Size = new System.Drawing.Size(75, 23);
            this.updateEmployeeBtn.TabIndex = 11;
            this.updateEmployeeBtn.Text = "Update";
            this.updateEmployeeBtn.UseVisualStyleBackColor = true;
            // 
            // insertEmployeeBtn
            // 
            this.insertEmployeeBtn.Location = new System.Drawing.Point(505, 428);
            this.insertEmployeeBtn.Name = "insertEmployeeBtn";
            this.insertEmployeeBtn.Size = new System.Drawing.Size(75, 23);
            this.insertEmployeeBtn.TabIndex = 10;
            this.insertEmployeeBtn.Text = "Insert";
            this.insertEmployeeBtn.UseVisualStyleBackColor = true;
            // 
            // loadEmployeeBtn
            // 
            this.loadEmployeeBtn.Location = new System.Drawing.Point(424, 428);
            this.loadEmployeeBtn.Name = "loadEmployeeBtn";
            this.loadEmployeeBtn.Size = new System.Drawing.Size(75, 23);
            this.loadEmployeeBtn.TabIndex = 9;
            this.loadEmployeeBtn.Text = "Load";
            this.loadEmployeeBtn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "label3";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(86, 181);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 18;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(86, 209);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 19;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(86, 237);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 20;
            // 
            // changePassBtn
            // 
            this.changePassBtn.Location = new System.Drawing.Point(31, 86);
            this.changePassBtn.Name = "changePassBtn";
            this.changePassBtn.Size = new System.Drawing.Size(126, 23);
            this.changePassBtn.TabIndex = 21;
            this.changePassBtn.Text = "Change Password";
            this.changePassBtn.UseVisualStyleBackColor = true;
            // 
            // logoutBtn
            // 
            this.logoutBtn.Location = new System.Drawing.Point(31, 125);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(126, 23);
            this.logoutBtn.TabIndex = 22;
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.UseVisualStyleBackColor = true;
            this.logoutBtn.Click += new System.EventHandler(this.LogoutBtnClicked);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 463);
            this.Controls.Add(this.logoutBtn);
            this.Controls.Add(this.changePassBtn);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.searchEmployeeTBox);
            this.Controls.Add(this.searchEmployeeBtn);
            this.Controls.Add(this.deleteEmployeeBtn);
            this.Controls.Add(this.updateEmployeeBtn);
            this.Controls.Add(this.insertEmployeeBtn);
            this.Controls.Add(this.loadEmployeeBtn);
            this.Controls.Add(this.searchAccountTBox);
            this.Controls.Add(this.searchAccountBtn);
            this.Controls.Add(this.deleteAccountBtn);
            this.Controls.Add(this.updateAccountBtn);
            this.Controls.Add(this.insertAccountBtn);
            this.Controls.Add(this.loadAccountBtn);
            this.Controls.Add(this.employeeGridView);
            this.Controls.Add(this.accountGridView);
            this.Controls.Add(this.welcomeLabel);
            this.Name = "Home";
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.accountGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.DataGridView accountGridView;
        private System.Windows.Forms.DataGridView employeeGridView;
        private System.Windows.Forms.Button loadAccountBtn;
        private System.Windows.Forms.Button insertAccountBtn;
        private System.Windows.Forms.Button updateAccountBtn;
        private System.Windows.Forms.Button deleteAccountBtn;
        private System.Windows.Forms.Button searchAccountBtn;
        private System.Windows.Forms.TextBox searchAccountTBox;
        private System.Windows.Forms.TextBox searchEmployeeTBox;
        private System.Windows.Forms.Button searchEmployeeBtn;
        private System.Windows.Forms.Button deleteEmployeeBtn;
        private System.Windows.Forms.Button updateEmployeeBtn;
        private System.Windows.Forms.Button insertEmployeeBtn;
        private System.Windows.Forms.Button loadEmployeeBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button changePassBtn;
        private System.Windows.Forms.Button logoutBtn;
    }
}