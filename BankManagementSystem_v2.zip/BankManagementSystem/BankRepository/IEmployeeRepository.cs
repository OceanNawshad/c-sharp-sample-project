﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankRepository
{
    interface IEmployeeRepository
    {
        bool Insert(Employee emp);
        bool Update(Employee emp);
        bool Delete(string employeeId);
        Employee GetEmployee(string employeeId);
        List<Employee> GetAllEmployees();
    }
}
