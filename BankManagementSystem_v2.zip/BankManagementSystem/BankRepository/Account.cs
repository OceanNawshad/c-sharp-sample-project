﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankRepository
{
    public class Account
    {
        private string accountId;
        private string accountHolderName;
        private double balance;

        public string AccountId
        {
            get { return accountId; }
            set { accountId = value; }
        }
        public string AccountHolderName
        {
            get { return accountHolderName; }
            set { accountHolderName = value; }
        }
        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }
    }
}
