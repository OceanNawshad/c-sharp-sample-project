﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankRepository
{
    public class AccountRepository : IAccountRepository
    {
        public bool Insert(Account a)
        {
            try
            {
                string query = "INSERT into Accounts VALUES ('" + a.AccountId + "', " + a.AccountHolderName + "', " + a.Balance + ")";
                DatabaseConnectionClass dcc = new DatabaseConnectionClass();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                dcc.CloseConnection();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool Update(Account a)
        {
            try
            {
                string query = "UPDATE Accounts SET AccountHolderName = '" + a.AccountHolderName + "', Balance = " + a.Balance + " WHERE AccountId= '" + a.AccountId + "'";
                DatabaseConnectionClass dcc = new DatabaseConnectionClass();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                dcc.CloseConnection();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool Delete(string accountId)
        {
            try
            {
                string query = "DELETE from Accounts WHERE AccountId = '" + accountId + "'";
                DatabaseConnectionClass dcc = new DatabaseConnectionClass();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                dcc.CloseConnection();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public Account GetAccount(string accountId)
        {
            string query = "SELECT * from Accounts WHERE AccountId= '" + accountId + "'";
            Account a = null;
            DatabaseConnectionClass dcc = new DatabaseConnectionClass();
            dcc.ConnectWithDB();
            SqlDataReader sdr = dcc.GetData(query);
            if (sdr.HasRows)
            {
                a = new Account();
                a.AccountId = sdr["AccountId"].ToString();
                a.AccountHolderName = sdr["AccountHolderName"].ToString();
                a.Balance = Convert.ToDouble(sdr["Balance"]);
            }
            dcc.CloseConnection();
            return a;
        }

        public List<Account> GetAllAccounts()
        {
            string query = "SELECT * from Accounts";
            List<Account> aList = new List<Account>();
            DatabaseConnectionClass dcc = new DatabaseConnectionClass();
            dcc.ConnectWithDB();
            SqlDataReader sdr = dcc.GetData(query);
            while (sdr.HasRows)
            {
                Account a = new Account();
                a.AccountId = sdr["AccountId"].ToString();
                a.AccountHolderName = sdr["AccountHolderName"].ToString();
                a.Balance = Convert.ToDouble(sdr["Balance"]);

                aList.Add(a);
            }
            return aList;
        }
    }
}
